package cs.sysu.utils;

public class FileRevision extends Pair<String, String> {
    public FileRevision(String a, String b) {
        super(a, b);
    }
}
