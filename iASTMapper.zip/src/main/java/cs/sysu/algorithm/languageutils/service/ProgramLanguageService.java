package cs.sysu.algorithm.languageutils.service;

public interface ProgramLanguageService {

    String removeCommentAndBlank(String codeStr);
}
