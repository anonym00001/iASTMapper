[COMMIT URL](https://github.com/hibernate/hibernate-orm/commit/28894f7fa9014348c14621e452680a00ef348aaa)
Path : hibernate-orm/hibernate-core/src/main/java/org/hibernate/engine/spi/ActionQueue.java