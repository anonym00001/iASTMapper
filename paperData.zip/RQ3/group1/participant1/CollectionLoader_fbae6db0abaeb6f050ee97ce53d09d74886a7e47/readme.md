[COMMIT URL](https://github.com/hibernate/hibernate-orm/commit/fbae6db0abaeb6f050ee97ce53d09d74886a7e47)
Path : hibernate-orm/core/src/main/java/org/hibernate/loader/collection/CollectionLoader.java