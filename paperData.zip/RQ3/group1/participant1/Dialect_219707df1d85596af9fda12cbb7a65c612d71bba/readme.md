[COMMIT URL](https://github.com/hibernate/hibernate-orm/commit/219707df1d85596af9fda12cbb7a65c612d71bba)
Path : hibernate-orm/hibernate-core/src/main/java/org/hibernate/dialect/Dialect.java