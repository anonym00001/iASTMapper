[COMMIT URL](https://github.com/hibernate/hibernate-orm/commit/812da6e7cdbe347972eb5ea678dd2bc4f31067a2)
Path : hibernate-orm/hibernate-core/src/main/java/org/hibernate/type/BasicTypeRegistry.java