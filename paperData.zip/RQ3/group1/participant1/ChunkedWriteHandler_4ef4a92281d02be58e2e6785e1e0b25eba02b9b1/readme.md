[COMMIT URL](https://github.com/netty/netty/commit/4ef4a92281d02be58e2e6785e1e0b25eba02b9b1)
Path : netty/src/main/java/org/jboss/netty/handler/stream/ChunkedWriteHandler.java