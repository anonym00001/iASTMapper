[COMMIT URL](https://github.com/hibernate/hibernate-orm/commit/9caca0ce37d5a2763d476c6fa2471addcca710ca)
Path : hibernate-orm/hibernate-core/src/test/java/org/hibernate/test/events/CallbackTest.java