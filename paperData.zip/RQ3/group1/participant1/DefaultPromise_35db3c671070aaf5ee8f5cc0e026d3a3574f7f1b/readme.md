[COMMIT URL](https://github.com/netty/netty/commit/35db3c671070aaf5ee8f5cc0e026d3a3574f7f1b)
Path : netty/common/src/main/java/io/netty/util/concurrent/DefaultPromise.java