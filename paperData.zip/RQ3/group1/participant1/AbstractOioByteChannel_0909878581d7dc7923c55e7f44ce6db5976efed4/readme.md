[COMMIT URL](https://github.com/netty/netty/commit/0909878581d7dc7923c55e7f44ce6db5976efed4)
Path : netty/transport/src/main/java/io/netty/channel/socket/oio/AbstractOioByteChannel.java